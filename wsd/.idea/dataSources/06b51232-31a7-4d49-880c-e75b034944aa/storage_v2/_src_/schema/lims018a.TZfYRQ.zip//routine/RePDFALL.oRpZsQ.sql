create
    definer = root@`%` procedure RePDFALL()
BEGIN
declare ReportNO varchar(100);
declare LastID bigint;
select ID from lijun_callLogs order by ID desc limit 1 into @LastID;
set @LastID=ifnull(@LastID,0);
insert into lijun_callLogs(`Name`,ExecTime,ExecSQL)
  Select 'RePDFALL',now(),'Call RePDFAll() ;' ;
while exists(SELECT a.acutal_report_no as RePDFSQL from lcgl_actual_report_info a 
	              left join lcgl_actual_pdf_l c on a.sample_id=c.sample_id 
                  where a.pdf_file_uri is null and c.st='PDF_WC' and @ReportNO<>'' ) DO
 SELECT @ReportNO = a.acutal_report_no 
   from lcgl_actual_report_info a 
	  left join lcgl_actual_pdf_l c on a.sample_id=c.sample_id 
      where a.pdf_file_uri is null and c.st='PDF_WC' and @ReportNO<>''
       order by a.acutal_report_no ASC limit 1 ;
Call RePDF(@ReportNO) ;

end while;
select * from lijun_callLogs where ID>@LastID order by ID ;
end;

