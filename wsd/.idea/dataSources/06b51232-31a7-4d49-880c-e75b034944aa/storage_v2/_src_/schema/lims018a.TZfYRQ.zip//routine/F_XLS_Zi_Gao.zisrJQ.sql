create
    definer = root@`%` function F_XLS_字高(字号 int, 字体 varchar(30)) returns double
BEGIN
 DECLARE ReturnValue real ;
 Case 字号    when  8 then set ReturnValue= 10.65 ;
              when  9 then set ReturnValue= 11.4 ;
              when 10 then set ReturnValue= 12.25 ; 
              when 11 then set ReturnValue= 13.875 ;
              when 12 then set ReturnValue= 14.7 ;
              when 13 then set ReturnValue= 15.45 ;
              when 14 then set ReturnValue= 19.05 ;
              else set ReturnValue= 25 ;
end case ;
   
  Return ReturnValue ;
END;

