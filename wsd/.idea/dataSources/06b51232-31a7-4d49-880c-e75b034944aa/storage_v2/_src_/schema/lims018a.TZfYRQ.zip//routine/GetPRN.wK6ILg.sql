create
    definer = root@`%` function GetPRN(ColumnName varchar(50), ByValue varchar(200)) returns varchar(36)
BEGIN
DECLARE MyPRN varchar(50) default '';  
IF (ColumnName='人员') THEN
  Select prn into MyPRN from ywpz_user_s where user_name=ByValue or login_name=ByValue ;
elseif (ColumnName='科室') THEN
  Select prn into MyPRN from ywpz_section_b where level_='section' and section_name=ByValue ;
elseif (ColumnName='组') THEN
  Select prn into MyPRN from ywpz_section_b where level_='group' and section_name=ByValue ;
elseif (ColumnName='机构') THEN
  Select prn into MyPRN from ywpz_org_b where org_name=ByValue ;
END IF; 
RETURN MyPRN ;
END;

