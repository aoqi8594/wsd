create
    definer = root@`%` procedure Lijun_SAY2LIMS(IN SampleID bigint)
label:BEGIN
declare OrderNO varchar(50) ; 
declare Items int ;
declare OrderIDFix bigint ;
declare SampleIDFix bigint ;
declare ItemIDFix bigint ;
Select @Items:= count(*),@OrderIDFix:=740000000,@SampleIDFix:=750000000,@ItemIDFix:=760000000
  from Lijun_ItemDetail where 样品ID=SampleID ;
if @Items=0 then
 LEAVE label; 
END IF;
Select @OrderNO:= 委托单号 from Lijun_ItemDetail where 样品ID=SampleID limit 1 ;
Select @Items:= count(1) from lims018a.lcgl_order_b where report_no=@OrderNO ;

if @Items=0 then 
  insert into lims018a.lcgl_order_b
    (id,up_ver,tenant_id,rollback_st,multi_sample_yn,data_sources_cd,operator_lname,business_type,bill_type,st,create_user,task_type_cd,reserv_3,reserv_4,reserv_16,req_blind_test_yn,req_copies,contract_yn,req_urgent_cd,req_judge_cd,task_from_cd,req_report_type_cd,report_no,org_jy_name,test_type_cd,req_get_report_cd,sample_from_cd,operator_name,accept_time)
    select 订单id+@OrderIDFix,'1','1','CS','Y','DDSL_NW','admin','10000','S','DDZT_YWC','admin','DDRW_ZJCY','N','食安云MySQL导入','620360576688','N','1','N','DDJJ_PT','DDPT_ZH','RWLY_WT','DDBL_ZW',委托单号,检验机构名称,检测类别,'自取',	'送检',受理人,受理日期
     from Lijun_ItemDetail  where 样品ID=SampleID limit 1 ;
		 
  insert into lims018a.lcgl_order_org_b
    (id,up_ver,create_time,tenant_id,wt_org_name,wt_addr,wt_contact_name,wt_tel,wt_zip,wt_fax,reserv_20)
    select 订单id+@OrderIDFix,'1',订单创建日期,'1',委托企业名称,委托企业地址,联系人,联系电话,邮编,传真,'食安云MySQL导入'
       from Lijun_ItemDetail  where 样品ID=SampleID limit 1 ;
			 
  insert into lims018a.lcgl_order_ext_b
    (id,up_ver,create_time,tenant_id,archive_yn,reserv_16)
      select 订单id+@OrderIDFix,'1',订单创建日期,'1','N','食安云MySQL导入' 
         from Lijun_ItemDetail  where 样品ID=SampleID limit 1 ;
				 
	insert into lims018a.lcgl_task_b
    (id,up_ver,create_time,rollback_st,proc_st,st,tenant_id,print_st,send_st,fee_yn,sub_is_end,is_modifie_item,sample_end_st,is_rept_updt,allow_add_ti,is_orig_mould,flow_change,is_finish,has_sub_17,has_sub_19,has_sub_40,has_sub_45,has_sub_50,has_sub_60,task_lock,node_id,quick_task_yn,node_name,process_schedule,part_end_yn,rework_remark)
      select 订单id+@OrderIDFix,'1',订单创建日期,'CS','PROC_CS','WTD_YWC','1','WDY','BG_WFF','N','N','Y','N','N','Y','N','N','N','N','N','N','N','N','N','N','end','N','完成','完成','N','食安云MySQL导入'
         from Lijun_ItemDetail  where 样品ID=SampleID limit 1 ;
			 
END IF;
Select @Items:= count(2) from lims018a.lcgl_order_sample_zj_b where report_no=@OrderNO ;
if @Items=0 then 
  insert into lims018a.lcgl_order_sample_zj_b
    (id,order_id,reserv_2_time,create_time,sample_status,sample_lining_up_yn,up_ver,tenant_id,is_syn,multi_sample_yn,sample_get_yn,proc_st,report_no,sample_name,sample_send_date,food_cat1_name,food_cat2_name,food_cat3_name,food_cat4_name,org_sc_name,reserv_12,sample_brand,sample_grade,sample_batch_no,sample_spec_name,rep_test_basis_resume,sample_quantity,sample_addition_status,sample_tagging_level,conclusion_result,sample_sealing_place,sample_residue_deal_type,sample_rep_type,reserv_13,reserv_14,sample_remark,reserv_16) 
    select 样品ID+@SampleIDFix,订单id+@OrderIDFix,'20',委托日期,'YPZT_RK','N','1','1','N','Y','N','PROC_CS',`样品/报告编号`,样品名称,委托日期,食品大类,食品亚类,食品次亚类,食品细类,生产单位,响应要求,商标,样品等级,`生产日期/批号`,样品规格,`执行标准/技术文件`,样品数量,样品形态,样品包装,检验结论用语,储存方式,样品处理,报告样式,报告类型,报告份数,样品备注,'食安云MySQL导入'
        from Lijun_ItemDetail  where 样品ID=SampleID limit 1 ;
				
  insert into lims018a.lcgl_order_sample_ext_b
    (id,order_id,create_time,tenant_id,up_ver,reserv_16,reserv_15)
      select 样品ID+@SampleIDFix,订单id+@OrderIDFix,委托日期,'1','1',样品颜色,'食安云MySQL导入'
        from Lijun_ItemDetail  where 样品ID=SampleID limit 1 ;
				
  insert into lims018a.lcgl_task_sub_b  
    (id,order_id,st,proc_st,rollback_st,has_ti_group,has_ti_assign,has_ti_test,has_ti_audit,has_ti_proof,has_ti_htps,create_time,print_st,send_st,tenant_id,up_ver,node_id,quick_task_yn,process_schedule,node_name,part_end_yn,test_start_time,test_end_time,conclusion_state,sub_ut_40_name,reserv1_time,sub_ut_45_lname,reserv2_time,sub_ut_50_name,sub_ut_50_lname1,ut_50_time,mark)
     select 样品ID+@SampleIDFix,订单id+@OrderIDFix,'WTD_YWC','PROC_CS','CS','N','N','N','N','N','N',委托日期,'WDY','BG_WFF','1','1','end','N','完成','完成','N',NULL,NULL,结论,编制人,编制日期,审核人,审核日期,报告签发人,复签人,签发日期,'食安云MySQL导入'
        from Lijun_ItemDetail  where 样品ID=SampleID limit 1 ;
insert into lims018a.lcgl_order_ti_b
    (id,order_id,sample_id,ti_name,proc_st,tenant_id,check_cycle,cost_val,create_time,up_ver,name1,name2,test_value,conclusion,test_value1_unit,test_remark,disp_or,reserv_16)
select 显示序号+@ItemIDFix,订单id+@OrderIDFix,样品ID+@SampleIDFix,CONCAT(一级项目,ifnull(二级项目,'')),'PROC_CS','1','0','0',受理日期,'1',一级项目,二级项目,检验结果,CASE 结果判定
        WHEN '合格项'   THEN 'QUALIFIED'
        WHEN '不合格项' THEN 'UNQUALIFIED'
        WHEN '未检验'   THEN 'NOT_KNOWN'
        WHEN '问题项'   THEN 'PROBLEM'
        WHEN '不判定项'   THEN 'NOT_JUDGE'
        ELSE ''
    END as 结果判定,检出限单位,说明,mod(显示序号,300),'食安云MySQL导入'
        from Lijun_ItemDetail  where 样品ID=SampleID  ;
				
  insert into lims018a.lcgl_order_ti_ext_b
    (id,order_id,sample_id,tenant_id,up_ver,create_time,proc_st,fun_std_full_name,std_full_name,std_test_limit,std_test_limit_unit,test_limit,ti_std_min_limit,ti_std_min_limit_unit,std_value_xx,ti_min_limit_unit,ti_std_max_limit,ti_std_max_limit_unit,std_value_sx,ti_max_limit_unit,remark)
  select 显示序号+@ItemIDFix,订单id+@OrderIDFix,样品ID+@SampleIDFix,'1','1',受理日期,'PROC_CS',检验依据,判定依据,标准方法检出限,标准检出限单位,方法检出限,标准最小允许限,标准最小允许限单位,最小允许限,最小允许限单位,标准最大允许限,标准最大允许限单位,最大允许限,最大允许限单位,'食安云MySQL导入'
         from Lijun_ItemDetail  where 样品ID=SampleID  ;
				 
  insert into lims018a.lcgl_task_ti_b
    (id,order_id,sample_id,st,	tenant_id,proc_st,rollback_st,up_ver,create_time,node_id,rollback_reason)
  select 显示序号+@ItemIDFix,订单id+@OrderIDFix,样品ID+@SampleIDFix,'WTD_YWC','1','PROC_CS','CS','1',受理日期,'end','食安云MySQL导入'
         from Lijun_ItemDetail  where 样品ID=SampleID  ;
		
   update Lijun_SampleState set 数据状态=3,订单创建日期=sysdate()  where 样品ID=SampleID ; 
				 
end if ;
END;

