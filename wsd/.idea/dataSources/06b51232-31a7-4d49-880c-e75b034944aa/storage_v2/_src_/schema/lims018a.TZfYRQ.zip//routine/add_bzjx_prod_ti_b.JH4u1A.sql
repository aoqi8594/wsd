create
    definer = root@`%` procedure add_bzjx_prod_ti_b(IN sl int)
BEGIN
DECLARE i INTEGER DEFAULT 0;
DECLARE new_item_name INTEGER DEFAULT 0;
DECLARE new_id BIGINT DEFAULT (SELECT MAX(id) FROM bzjx_prod_ti_b)+1 ;
WHILE i<sl DO
	INSERT INTO `bzjx_prod_ti_b`(`id`, `prod_prn`, `ti_name`, `disp_or`, `create_time`, `create_user`, `update_time`, `update_user`, `st`, `up_ver`, `remark`, `name1`, `name2`, `name3`, `name4`, `name5`, `name6`, `name_en`, `prj_unit`, `test_condition_name`, `test_condition_prn`, `judge_equation`, `revision_digit`, `fun_std_prn`, `fun_std_id`, `fun_std_name`, `fun_std_method_id`, `fun_std_method_name`, `fun_std_code`, `original_mould_prn`, `original_mould_name`, `test_eqp`, `duty_section_prn`, `duty_section_name`, `duty_person_prn`, `duty_person_lname`, `duty_person_name`, `fee_method`, `template_prn`, `template_name`, `std_id`, `std_prn`, `std_name`, `std_code`, `alias_name`, `check_cycle`, `accept_type`, `ability_verify`, `project_classify`, `code`, `cost_val`, `std_value`, `is_affected`, `father_ti_name`, `ti_id`, `std_state`, `template_type`, `ti_id0`, `reserv_1`, `reserv_2`, `reserv_3`, `reserv_4`, `reserv_5`, `reserv_6`, `reserv_7`, `reserv_8`, `reserv_9`, `reserv_11`, `reserv_10`, `reserv_12`, `reserv_13`, `reserv_14`, `reserv_15`, `reserv_16`, `old_id`, `old_std_id`, `right_cd`) VALUES (new_id, '707557182440',new_item_name, 6, NOW(), NULL, NOW(), NULL, '', 1, '', new_item_name, '', '', '', '', NULL, NULL, 'ug', NULL, NULL, NULL, 3, '', NULL, '', NULL, NULL, NULL, '', '', '', '672407825536', '微生物', '', '', '', '', NULL, NULL, NULL, NULL, 'ljhtest03', NULL, NULL, 1, NULL, NULL, NULL, NULL, 123.00, '<15', NULL, NULL, new_id, NULL, 'MBMS_MSO', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
	SET i=i+1;
	set new_id=new_id+1;
	set new_item_name=new_item_name+1;
END WHILE;
END;

