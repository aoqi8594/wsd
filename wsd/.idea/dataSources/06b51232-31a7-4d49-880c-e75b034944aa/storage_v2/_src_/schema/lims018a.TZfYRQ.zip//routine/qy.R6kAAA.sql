create
    definer = root@`%` procedure qy()
begin
declare i int;
while exists(select * from Lijun_SampleState where 数据状态=1) DO
   select @i:=样品ID from Lijun_SampleState where  数据状态=1 order by 样品ID asc limit 1 ;
   call Lijun_SAY2LIMS (@i) ;
end while;
end;

