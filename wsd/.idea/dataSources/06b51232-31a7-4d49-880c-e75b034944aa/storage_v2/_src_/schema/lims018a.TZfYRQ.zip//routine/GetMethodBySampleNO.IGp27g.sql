create
    definer = root@`%` procedure GetMethodBySampleNO(IN SampleNO varchar(50), IN Tester varchar(30))
BEGIN
declare TrueName nvarchar(20);
Set TrueName=Case Tester when 'admin' Then '系统管理员' else  Tester end ;
select manager_prns from ywpz_user_s
  where user_name=TrueName ;
END;

