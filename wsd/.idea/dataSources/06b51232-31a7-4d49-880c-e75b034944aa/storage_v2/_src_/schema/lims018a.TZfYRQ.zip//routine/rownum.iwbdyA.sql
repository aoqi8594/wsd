create
    definer = root@`%` function rownum() returns int
BEGIN
    
     
    SET @rno = @rno + 1;  
    RETURN @rno; 
END;

