create
    definer = root@`%` procedure RePDF(IN ReportNO varchar(50))
BEGIN

update lcgl_actual_pdf_l 	set st='PDF_CS' where sample_id in
  (select sample_id from  lcgl_actual_report_info
                       where acutal_report_no=ReportNO) ;
											 
 select id,order_id,sample_id,create_time 创建日期,st 状态 from lcgl_actual_pdf_l where sample_id in
  (select sample_id from  lcgl_actual_report_info
                       where acutal_report_no=ReportNO) ;

END;

