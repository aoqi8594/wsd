create
    definer = root@`%` procedure double_sign(IN sampleId bigint)
begin
 DECLARE done INT DEFAULT FALSE;
 declare sectionPrn varchar(250);
 declare diffSectionPrns varchar(250);
 DECLARE cur1 CURSOR FOR select distinct  duty_section_prn from lcgl_order_ti_b where sample_id=sampleId and duty_section_prn not in (sectionPrns);
 DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
 select @taskCount=count(*) from ACT_RU_TASK  a inner join lcgl_task_sub_b b  on  a.proc_inst_id_=b.subtask_instance_id where b.id=sampleId;
 
 if(@taskCount>1) then
   select @ut50Lname=sub_ut_50_lname from lcgl_task_sub_b where id=sampleId;
   select @sectionPrns=manager_prns ,@sectionPrnInDb=section_prn from ywpz_user_s where user_name=@ut50Lname;
	 update lcgl_order_sample_zj_b set reserv_1=@ut50Lname where id=sampleId;
	 if(sectionPrns is null) THEN
					 set @sectionPrns=@sectionPrnInDb;
	 else set @sectionPrns=@sectionPrns+','+@sectionPrnInDb;
	 end if;
	 set diffSectionPrns='sdafsd';
	 OPEN cur1;
		read_loop: LOOP
			FETCH cur1 INTO sectionPrn;
			IF done THEN
				LEAVE read_loop;
			END IF;
			set diffSectionPrns=diffSectionPrns+''''+sectionPrn+''''+',';
		END LOOP;
	 CLOSE cur1;
	 update lcgl_order_sample_zj_b set reserv_2='Y' where id=sampleId;
else update lcgl_order_sample_zj_b set reserv_2='N',reserv_3=@taskCount where id=sampleId;
end if;
commit;
end;

