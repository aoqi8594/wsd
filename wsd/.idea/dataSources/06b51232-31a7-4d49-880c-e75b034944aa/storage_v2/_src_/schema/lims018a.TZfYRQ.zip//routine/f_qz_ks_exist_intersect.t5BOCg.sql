create
    definer = root@`%` function f_qz_ks_exist_intersect(strA varchar(4000), strB varchar(4000), splitStr varchar(10)) returns int
BEGIN
	DECLARE strALen,strBLen,i,j,exist_intersect INT DEFAULT 0;
	DECLARE subA,subB VARCHAR(100) DEFAULT '';
	IF strA='' or strA is null or strB='' or strB is null THEN
		RETURN 0;
	END IF;
	SET strALen = length(strA) - length(REPLACE(strA, splitStr, ''))+1;
	SET strBLen = length(strB) - length(REPLACE(strB, splitStr, ''))+1;
	SET i = 1;
	IF LOCATE(',',strA)>0 THEN
		WHILE i <= strALen DO
			SET subA = REVERSE(SUBSTRING_INDEX(REVERSE(SUBSTRING_INDEX(strA, ",", i)), ",", 1));
			SET j = 1;
			IF LOCATE(subA,strB)>0 THEN
				WHILE j <= strBLen DO
					SET subB = REVERSE(SUBSTRING_INDEX(REVERSE(SUBSTRING_INDEX(strB, ",", j)), ",", 1));
					IF subA=subB THEN
						RETURN 1;
					END IF;
					SET j = j + 1;
				END WHILE;
			END	IF;
			SET i = i + 1;
		END WHILE;
	ELSE
		IF LOCATE(strA,strB)>0 THEN
			SET j = 1;
			WHILE j <= strBLen DO
				SET subB = REVERSE(SUBSTRING_INDEX(REVERSE(SUBSTRING_INDEX(strB, ",", j)), ",", 1));
				IF strA=subB THEN
					RETURN 1;
				END IF;
				SET j = j + 1;
			END WHILE;
		END	IF;
	END IF;
	RETURN exist_intersect;
END;

