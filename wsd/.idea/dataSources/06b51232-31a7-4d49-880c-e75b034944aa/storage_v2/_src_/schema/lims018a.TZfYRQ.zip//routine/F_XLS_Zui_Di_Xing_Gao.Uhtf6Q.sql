create
    definer = root@`%` function F_XLS_最低行高(列宽 double, 字体 varchar(30), 字号 int, Str varchar(4000)) returns double
BEGIN
 DECLARE 字长,英文字符 int ;
 DECLARE ReturnValue real ;
 DECLARE Char10 varchar(2) ;
 DECLARE TmpStr Varchar(1000) ;
 if right(rtrim(Str),1)=char(10) then Set Str=rtrim(Str)+'1' ; end if ;
 Set Str=replace(Str,char(13),'') ;
 Set 字长=char_length(Str) ;
 Set 英文字符=(char_length(Str)*3-length(Str))/2 ;
 Set ReturnValue=0 ;
 Set Char10=char(10) ;
 if 列宽=0 or 字号=0 or 字长=0 then Return 0 ; end if ;
 While (instr(Str,Char10)<>0) Do 
     Set TmpStr=(substring(Str,1,instr(Str,Char10)-1)) ; 
     Set Str   =INSERT(Str,1,instr(Str,Char10),'') ;
     Set 字长=(case char_length(TmpStr) when 0 then 1 else char_length(TmpStr) end) ;
     Set 英文字符=(char_length(TmpStr)*3-length(TmpStr))/2 ;
     Set ReturnValue=ReturnValue+CEILING((字长*1.0-英文字符/2*0.88)/ FLOOR(列宽/F_XLS_字宽(字号,字体)) )
                     *F_XLS_字高(字号,字体) ;
   end While ;
if Str<>'' then 
     Set 字长=char_length(Str) ;
		 Set 英文字符=(char_length(Str)*3-length(Str))/2 ;
     Set ReturnValue=ReturnValue+CEILING((字长*1.0-英文字符/2*0.88)/ FLOOR(列宽/F_XLS_字宽(字号,字体)) )
                     *F_XLS_字高(字号,字体) ;
   end if ;

   
  if ReturnValue>=400 then Return 400 ; end if ;
  Return round(ReturnValue,3) ;
END;

