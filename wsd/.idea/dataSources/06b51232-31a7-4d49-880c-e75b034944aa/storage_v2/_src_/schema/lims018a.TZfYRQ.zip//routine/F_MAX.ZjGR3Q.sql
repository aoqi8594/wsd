create
    definer = root@`%` function F_MAX(Real1 double, Real2 double, Real3 double, Real4 double, Real5 double,
                                      Real6 double) returns double
BEGIN
 DECLARE ReturnValue real ;
  Select max(Value) into ReturnValue from
   ( select Real1 as Value
        union select Real2
        union select Real3
        union select Real4
        union select Real5
        union select Real6 ) R ;
   
  Return ReturnValue ;
END;

