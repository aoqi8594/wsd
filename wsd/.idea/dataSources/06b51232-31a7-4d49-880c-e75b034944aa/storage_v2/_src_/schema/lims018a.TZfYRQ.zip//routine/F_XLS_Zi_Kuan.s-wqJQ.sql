create
    definer = root@`%` function F_XLS_字宽(字号 int, 字体 varchar(30)) returns double
BEGIN
 DECLARE ReturnValue real ;
 Case 字号   when  8 then set ReturnValue=1.375 ;
              when  9 then set ReturnValue= 1.5 ;
              when 10 then set ReturnValue= 1.625 ; 
              when 11 then set ReturnValue= 1.875 ;
              when 12 then set ReturnValue= 2.0 ;
              when 13 then set ReturnValue= 2.15 ;
              when 14 then set ReturnValue= 2.4 ;
              else set ReturnValue= 2.5 ;
end case ;
   
  Return ReturnValue ;
END;

