create definer = root@`%` view v_person_info as
select `u`.`prn`                   AS `用户PRN`,
       `u`.`id`                    AS `用户ID`,
       `u`.`login_name`            AS `登录名`,
       `u`.`user_name`             AS `姓名`,
       `u`.`sex`                   AS `性别`,
       `u`.`section_name`          AS `所属科室`,
       `u`.`org_name`              AS `所属机构`,
       `o`.`prn`                   AS `所属机构PRN`,
       `o`.`id`                    AS `所属机构ID`,
       `s`.`prn`                   AS `科室PRN`,
       `s`.`id`                    AS `科室id`,
       `s`.`bl_sect_prn`           AS `父级科室PRN`,
       `s`.`bl_sect_name`          AS `父级科室名称`,
       `u`.`province`              AS `省`,
       `u`.`city`                  AS `市`,
       `u`.`area`                  AS `区县`,
       `u`.`province_prn`          AS `省PRN`,
       `u`.`city_prn`              AS `市PRN`,
       `u`.`county_prn`            AS `区县PRN`,
       `u`.`section_prn`           AS `所属部门PRN`,
       `u`.`manager_section_name`  AS `管理科室名称`,
       `u`.`manager_prns`          AS `管理科室PRN`,
       `u`.`parent_section_xzname` AS `检验组名称`,
       `u`.`parent_section_xzprn`  AS `检验组PRN`
from ((`lims018a`.`ywpz_user_s` `u` left join `lims018a`.`ywpz_section_b` `s` on ((`s`.`prn` = `u`.`section_prn`)))
         left join `lims018a`.`ywpz_org_b` `o` on ((`o`.`prn` = `u`.`org_prn`)));

-- comment on column v_person_info.用户PRN not supported: 全局唯一标识

-- comment on column v_person_info.登录名 not supported: 用户账号

-- comment on column v_person_info.姓名 not supported: 姓名

-- comment on column v_person_info.性别 not supported: 性别

-- comment on column v_person_info.所属科室 not supported: 科室名称

-- comment on column v_person_info.所属机构 not supported: 机构名称

-- comment on column v_person_info.所属机构PRN not supported: 全局唯一id

-- comment on column v_person_info.科室PRN not supported: 全局唯一id

-- comment on column v_person_info.科室id not supported: 自增id

-- comment on column v_person_info.父级科室PRN not supported: 父级科室prn

-- comment on column v_person_info.父级科室名称 not supported: 父级科室名称

-- comment on column v_person_info.省 not supported: 省

-- comment on column v_person_info.市 not supported: 市

-- comment on column v_person_info.区县 not supported: 区

-- comment on column v_person_info.省PRN not supported: 省的prn

-- comment on column v_person_info.市PRN not supported: 市的prn

-- comment on column v_person_info.区县PRN not supported: 县的prn

-- comment on column v_person_info.所属部门PRN not supported: 所属部门prn

-- comment on column v_person_info.管理科室名称 not supported: 管理科室名称

-- comment on column v_person_info.管理科室PRN not supported: 管理科室prn

-- comment on column v_person_info.检验组名称 not supported: 检验小组

-- comment on column v_person_info.检验组PRN not supported: 检验小组prn

