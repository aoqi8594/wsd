create
    definer = root@`%` procedure appendTestTiB(IN orderId bigint, IN sampleId bigint)
begin
    declare startId int default 1;
    set @currentId=orderId<<6;
    delete from lcgl_order_ti_b where order_id=orderId;
    delete from lcgl_task_ti_b where order_id=orderId;
    set @lcglOrderTiInsert="insert into lcgl_order_ti_b(id,order_id,sample_id,name1,ti_name,create_time) ";
    set @lcglOrderTiInsert=concat(@lcglOrderTiInsert,"values (?,?,?,?,?,'2020-03-16 22:20:41')");
    set @taskTiTiInsert="insert into lcgl_task_ti_b(id,order_id,sample_id,create_time) values(?,?,?,'2020-3-16 22:39:59')";
    set @sampleId1=sampleId;
    set @orderId1=orderId;
    prepare lcglOrderTiInsertStmt from @lcglOrderTiInsert;
    prepare taskTiTiInsertStmt from @taskTiTiInsert;
    while startId< 31 do 
      set @currentId=@currentId+1;
      set @name1=cast(startId as char);
      execute lcglOrderTiInsertStmt using @currentId,@orderId1,@sampleId1,@name1,@name1;
      execute taskTiTiInsertStmt using @currentId,@orderId1,@sampleId1;
      set startId=startId+1;
    end while;
    deallocate prepare lcglOrderTiInsertStmt;
    deallocate prepare taskTiTiInsertStmt;
end;

