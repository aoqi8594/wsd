create
    definer = root@`%` function IsNum(str varchar(60)) returns int
BEGIN
  DECLARE iResult tinyint DEFAULT 0;
  IF str is null THEN return 0; END IF;
  IF str = '' THEN return 0; END IF;
  SELECT str REGEXP '^(\-?[[:digit:]]+(\.[[:digit:]]+)?)(e(\-?[[:digit:]]+(\.[[:digit:]]+)?))?$' INTO iResult;
  IF iResult = 1 THEN
    RETURN 1;
  ELSE
    RETURN 0;
  END IF;
  RETURN 0;
END;

