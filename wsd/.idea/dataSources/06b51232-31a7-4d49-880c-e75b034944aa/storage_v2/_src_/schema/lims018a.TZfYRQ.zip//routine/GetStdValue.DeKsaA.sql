create
    definer = root@`%` function GetStdValue(MinStdValue varchar(50), MaxStdValue varchar(50)) returns varchar(100)
BEGIN
DECLARE v_Tmp varchar(100) default '';
IF MinStdValue is null or MinStdValue='' or MinStdValue='/' THEN
  if  MaxStdValue is null or MaxStdValue='' or MaxStdValue='/' THEN
	  set v_Tmp='' ;
  else
    if IsNum(MaxStdValue)=1 then set v_Tmp=concat('≤',MaxStdValue) ; else set v_Tmp=MaxStdValue ; end if ;
	end if ;
else
  if  MaxStdValue is null or MaxStdValue='' or MaxStdValue='/' THEN
	  if IsNum(MinStdValue)=1 then set v_Tmp=concat('≥',MinStdValue) ; else set v_Tmp=MinStdValue ; end if ;
	else
		set v_Tmp=concat(MinStdValue,'～',MaxStdValue) ; 
  end if ;
END IF;
RETURN v_Tmp;
END;

