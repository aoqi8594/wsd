create
    definer = root@`%` function F_项目最低行高(ItemID bigint, TmpID bigint) returns double
BEGIN
  
  RETURN 30.0;
END;

