create
    definer = root@`%` procedure appendTestOrder(IN rowCount int)
begin
    set @aRow=1;
    set @createTime =SYSDATE();
    
    delete from lcgl_order_b where id< 10000000;
    delete from lcgl_order_ext_b where id< 10000000;
    delete from lcgl_order_org_b where id< 10000000;
    delete from lcgl_task_b where id< 10000000;
    delete from lcgl_order_sample_zj_b where id< 10000000;
    delete from lcgl_task_sub_b where id< 10000000;
    delete from lcgl_task_ti_b where id<  70000000;
    delete from lcgl_order_ti_b where id<  70000000;

    set @lcglOrderInsert="insert into lcgl_order_b(id,create_time,operator_lname,create_user,bus_section_prn,main_section_prn,org_wt_name,sample_name) values(?,?,'admin','admin','438754891760','438754891760','qzsoft','qzsoft sample')";
    set @lcglOrderExtInsert="insert into lcgl_order_ext_b(id,create_time) values(?,?)";
    set @lcglOrderOrgInsert="insert into lcgl_order_org_b(id,order_id,create_time,org_type,org_name) values(?,?,?,'DWWT','qzsoft')";
    set @lcglTaskInsert="insert into lcgl_task_b(id,create_time) values(?,?)";
    set @lcglSampleInsert="insert into lcgl_order_sample_zj_b(id,create_time,order_id,sample_status,sample_name) values(?,?,?,'YPZT_DRK','qzsoft sample')";
    set @lcglSubtaskInsert="insert into lcgl_task_sub_b(id,create_time,order_id,node_id,st,proc_st,rollback_st) values(?,?,?,'ut_10','WTD_DCL','PROC_CS','CS')";
    prepare lcglOrderInsertStmt from @lcglOrderInsert;
    prepare lcglOrderExtInsertStmt from @lcglOrderExtInsert;
    prepare lcglOrderOrgInsertStmt from @lcglOrderOrgInsert;
    prepare lcglTaskInsertStmt from @lcglTaskInsert;
    prepare lcglSampleInsertStmt from @lcglSampleInsert;
    prepare lcglSubtaskInsertStmt from @lcglSubtaskInsert;
    while @aRow<= rowCount do 
        start transaction;
        execute lcglOrderInsertStmt using @aRow,@createTime;
        execute lcglOrderExtInsertStmt using @aRow,@createTime;
        execute lcglOrderOrgInsertStmt using @aRow,@aRow,@createTime;
        execute lcglTaskInsertStmt using @aRow,@createTime;
        execute lcglSampleInsertStmt using @aRow,@createTime,@aRow;
        execute lcglSubtaskInsertStmt using @aRow,@createTime,@aRow;
        call appendTestTiB(@aRow,@aRow);
        set @aRow=@aRow+1;
    end while;
    deallocate prepare lcglOrderInsertStmt;
    deallocate prepare lcglOrderExtInsertStmt;
    deallocate prepare lcglTaskInsertStmt;
    deallocate prepare lcglSampleInsertStmt;
    deallocate prepare lcglSubtaskInsertStmt;
    deallocate prepare lcglOrderOrgInsertStmt;
end;

